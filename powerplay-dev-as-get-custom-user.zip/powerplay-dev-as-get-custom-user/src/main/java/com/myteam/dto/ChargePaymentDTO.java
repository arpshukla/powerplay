package com.myteam.dto;

public class ChargePaymentDTO {

}
