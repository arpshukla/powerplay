package com.myteam.dto;

public class MakePaymentResponseDTO {

}
