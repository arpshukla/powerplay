package com.myteam.respponse;

public class LogoutResponse extends ServiceResponse{

}
