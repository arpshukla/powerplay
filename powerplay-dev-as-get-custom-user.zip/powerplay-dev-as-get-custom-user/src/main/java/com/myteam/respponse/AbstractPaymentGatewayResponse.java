package com.myteam.respponse;

import java.io.Serializable;

public abstract class AbstractPaymentGatewayResponse implements Serializable{

}
