package com.myteam.request;

import java.io.Serializable;

public class BasicPaytmTransactionRequest implements Serializable{

}
