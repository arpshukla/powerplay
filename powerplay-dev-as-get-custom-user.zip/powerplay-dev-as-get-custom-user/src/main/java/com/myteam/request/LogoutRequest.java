package com.myteam.request;

public class LogoutRequest extends ServiceRequest{

}
