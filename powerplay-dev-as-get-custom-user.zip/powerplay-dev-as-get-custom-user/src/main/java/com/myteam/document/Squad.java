package com.myteam.document;

public class Squad {

}
