package com.myteam.respponse;

import java.util.ArrayList;
import java.util.List;

import com.myteam.dto.JoinedContestDTO;

public class JoinedContestResponse extends ServiceResponse{
	
	private List<JoinedContestDTO> joinedContests = new ArrayList<>();

	public List<JoinedContestDTO> getJoinedContests() {
		return joinedContests;
	}

	public void setJoinedContests(List<JoinedContestDTO> joinedContests) {
		this.joinedContests = joinedContests;
	}

	@Override
	public String toString() {
		return "JoinedContestResponse [joinedContests=" + joinedContests + "]";
	}
}
